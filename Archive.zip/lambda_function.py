import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
from datetime import datetime, date, timedelta
from dateutil import parser
from pytz import timezone
import pytz

def lambda_handler(event, context):
    client = boto3.resource('dynamodb')
    entries_table = client.Table('entries')
    
    current_datetime = datetime.now(tz=pytz.timezone('US/Eastern'))
    
    existing_entries = entries_table.scan()
    
    for entry in existing_entries:
        entry_datetime = datetime_from_string(entry['entry_date'], entry['post_time'])
        if (entry_datetime > current_datetime):
            entries_table.delete_item(Key={'unique_id', entry['unique_id']})
            
    return {
        'statusCode': 200,
        'body': json.dumps('Process completed.')
    }
